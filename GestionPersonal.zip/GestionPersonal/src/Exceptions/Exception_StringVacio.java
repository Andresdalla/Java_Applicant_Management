/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exceptions;

/**
 *
 * @author socar
 */
public class Exception_StringVacio extends Exception {
      public Exception_StringVacio (String descripcion){
        super(descripcion);
}
}
